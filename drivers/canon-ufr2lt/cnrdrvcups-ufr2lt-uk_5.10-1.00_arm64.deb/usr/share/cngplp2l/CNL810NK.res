<?xml version="1.0"?>
<KeyTextList>
<Item key="MediaType_PlainPaper">Plain</Item>
<Item key="MediaType_PlainPaperL">Plain L</Item>
<Item key="MediaType_PlainPaperL2">Plain L2</Item>
<Item key="MediaType_PlainPaperH">Plain H</Item>
<Item key="MediaType_HEAVY1">Heavy 1</Item>
<Item key="MediaType_HEAVY2">Heavy 2</Item>
<Item key="MediaType_HEAVY3">Heavy 3</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
<Item key="PageSize_Foolscap">Foolscap/Folio</Item>
</KeyTextList>
