<?xml version="1.0"?>
<KeyTextList>
<Item key="MediaType_PlainPaper1">Plain 1</Item>
<Item key="MediaType_PlainPaper2">Plain 2</Item>
<Item key="MediaType_HEAVY1">Heavy 1</Item>
<Item key="MediaType_HEAVY2">Heavy 2</Item>
<Item key="MediaType_THIN1">Thin 1</Item>
<Item key="MediaType_THIN2">Thin 2</Item>
<Item key="MediaType_1SIDECOATED1">Coated 1</Item>
<Item key="MediaType_1SIDECOATED2">Coated 2</Item>
<Item key="MediaType_1SIDECOATED3">Coated 3</Item>
<Item key="MediaType_1SIDECOATED4">Coated 4</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
<Item key="PageSize_Foolscap">Foolscap</Item>
</KeyTextList>
