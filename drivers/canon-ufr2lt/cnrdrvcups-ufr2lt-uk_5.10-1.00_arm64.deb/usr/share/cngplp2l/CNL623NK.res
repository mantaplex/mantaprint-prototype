<?xml version="1.0"?>
<KeyTextList>
<Item key="MediaType_PlainPaper">Plain</Item>
<Item key="MediaType_PlainPaperL">Plain L</Item>
<Item key="MediaType_HEAVY">Heavy</Item>
<Item key="MediaType_ROUGH1">Rough 1</Item>
<Item key="MediaType_ROUGH2">Rough 2</Item>
<Item key="PageSize_Com10">Envelope No.10 (COM10)</Item>
</KeyTextList>
